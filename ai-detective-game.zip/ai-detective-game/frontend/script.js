let collectedClues = [];

function startGame() {
    document.getElementById("game-area").classList.remove("hidden");
}

function collectClue(clue) {

    if (!collectedClues.includes(clue)) {

        collectedClues.push(clue);

        let li = document.createElement("li");
        li.innerText = clue;

        document.getElementById("clue-list").appendChild(li);

        alert(clue + " collected!");
    }
}

function interrogate(name) {

    let message = "";

    if (name === "Assistant") {
        message = "I was working in the lab.";
    }

    else if (name === "Guard") {
        message = "I saw someone enter the building.";
    }

    else {
        message = "I had a business meeting.";
    }

    alert(name + ": " + message);
}

function solveCase() {

    if (collectedClues.includes("Fingerprint")) {
        alert("You solved the mystery! The Guard is guilty.");
    }

    else {
        alert("Not enough evidence. Criminal escaped.");
    }
}