from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)

CORS(app)

suspects = [
    {
        "name": "Assistant",
        "alibi": "Working in lab"
    },

    {
        "name": "Guard",
        "alibi": "Checking cameras"
    },

    {
        "name": "Business Rival",
        "alibi": "In a meeting"
    }
]

@app.route("/suspects")

def get_suspects():
    return jsonify(suspects)

@app.route("/")

def home():
    return "AI Detective Backend Running"

if __name__ == "__main__":
    app.run(debug=True)