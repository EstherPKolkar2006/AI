from tkinter import *
from tkinter import messagebox
import wikipedia
import speech_recognition as sr
import pyttsx3

# ---------------- MAIN WINDOW ----------------
root = Tk()
root.title("AI HEALTH ASSISTANT BOT")
root.geometry("1000x650")
root.configure(bg="black")

# ---------------- VOICE ENGINE ----------------
engine = pyttsx3.init()

def speak(text):
    engine.say(text)
    engine.runAndWait()

# ---------------- HEALTH DATABASE ----------------
health_data = {
    "diabetes":
        "Diabetes is a disease that occurs when blood sugar is too high. "
        "Common symptoms include increased thirst, frequent urination, "
        "fatigue, and blurred vision.",

    "fever":
        "Fever is a temporary increase in body temperature. "
        "It usually happens because of infection or illness.",

    "asthma":
        "Asthma is a condition in which airways become narrow and swollen. "
        "It may cause difficulty in breathing and coughing.",

    "heart attack":
        "A heart attack happens when blood flow to the heart is blocked. "
        "Symptoms include chest pain, sweating, and shortness of breath.",

    "migraine":
        "Migraine is a severe headache often accompanied by nausea "
        "and sensitivity to light.",

    "cancer":
        "Cancer is a disease in which abnormal cells divide uncontrollably "
        "and destroy body tissue."
}

# ---------------- SEARCH FUNCTION ----------------
def search():
    topic = entry.get().strip().lower()

    if topic == "":
        messagebox.showwarning("Warning", "Please enter a topic")
        return

    text_area.delete(1.0, END)

    # FIRST SEARCH IN LOCAL HEALTH DATA
    if topic in health_data:
        result = health_data[topic]

        text_area.insert(END, "TOPIC: " + topic.upper() + "\n\n")
        text_area.insert(END, result)

        speak(result)

    else:
        # SEARCH FROM WIKIPEDIA
        try:
            result = wikipedia.summary(topic, sentences=8)

            text_area.insert(END, "TOPIC: " + topic.upper() + "\n\n")
            text_area.insert(END, result)

            speak(result)

        except:
            text_area.insert(
                END,
                "Topic not found.\n\nTry topics like:\n"
                "- diabetes\n"
                "- fever\n"
                "- asthma\n"
                "- migraine\n"
                "- cancer\n"
                "- heart attack"
            )

# ---------------- VOICE SEARCH ----------------
def voice_search():
    recognizer = sr.Recognizer()

    try:
        with sr.Microphone() as source:
            messagebox.showinfo("Voice Search", "Speak now")
            audio = recognizer.listen(source)

        voice_text = recognizer.recognize_google(audio)

        entry.delete(0, END)
        entry.insert(0, voice_text)

        search()

    except:
        messagebox.showerror("Error", "Voice not recognized")

# ---------------- CLEAR FUNCTION ----------------
def clear():
    entry.delete(0, END)
    text_area.delete(1.0, END)

# ---------------- TITLE ----------------
title = Label(
    root,
    text="AI HEALTH ASSISTANT BOT",
    font=("Arial", 32, "bold"),
    bg="black",
    fg="lime"
)
title.pack(pady=20)

# ---------------- SEARCH FRAME ----------------
frame = Frame(root, bg="black")
frame.pack(pady=10)

# ---------------- ENTRY ----------------
entry = Entry(
    frame,
    font=("Arial", 20),
    width=35,
    bg="#222222",
    fg="white",
    insertbackground="white"
)
entry.grid(row=0, column=0, padx=10)

# ---------------- BUTTONS ----------------
search_btn = Button(
    frame,
    text="Search",
    font=("Arial", 15, "bold"),
    bg="green",
    fg="white",
    padx=15,
    command=search
)
search_btn.grid(row=0, column=1, padx=10)

voice_btn = Button(
    frame,
    text="Voice",
    font=("Arial", 15, "bold"),
    bg="blue",
    fg="white",
    padx=15,
    command=voice_search
)
voice_btn.grid(row=0, column=2, padx=10)

clear_btn = Button(
    frame,
    text="Clear",
    font=("Arial", 15, "bold"),
    bg="red",
    fg="white",
    padx=15,
    command=clear
)
clear_btn.grid(row=0, column=3, padx=10)

# ---------------- TEXT AREA ----------------
text_area = Text(
    root,
    font=("Arial", 15),
    wrap=WORD,
    bg="#111111",
    fg="white"
)
text_area.pack(padx=20, pady=20, fill=BOTH, expand=True)

# ---------------- SCROLLBAR ----------------
scrollbar = Scrollbar(text_area)
scrollbar.pack(side=RIGHT, fill=Y)

text_area.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=text_area.yview)

# ---------------- RUN APP ----------------
root.mainloop()